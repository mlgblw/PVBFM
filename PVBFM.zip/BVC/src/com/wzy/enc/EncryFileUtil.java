package com.wzy.enc;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;

public class EncryFileUtil {


	public static void encryptFile(String filename, String aeskey) throws Exception {
		String aimfile = "D:\\11111\\PVBFM\\FileList\\" + filename;
		File file = new File("D:\\11111\\PVBFM\\FileList\\" + filename);
		OutputStream zipOutputPathStream = new FileOutputStream(new File("D:\\11111\\PVBFM\\FileList\\" + filename));
		Cipher cipher = AesHelper.getEncryptCipher(aeskey);
		OutputStream cipherOutputStream = new CipherOutputStream(zipOutputPathStream, cipher);
		ZipOutputStream zipOutputStream = new ZipOutputStream(cipherOutputStream);
		zipOutputStream.putNextEntry(new ZipEntry(aimfile));

		InputStream fileInputStream = new FileInputStream(new File(aimfile));

		BufferedInputStream bis = new BufferedInputStream(fileInputStream);
		BufferedOutputStream bos = new BufferedOutputStream(zipOutputStream);

		byte[] bytes = new byte[1024];
		int len = 0;
		while ((len = bis.read(bytes)) != -1) {
			bos.write(bytes, 0, len);
		}
		bos.flush();
		bos.close();
		bis.close();
		fileInputStream.close();
		zipOutputStream.close();
		cipherOutputStream.close();
		zipOutputPathStream.close();

	}


	public static void decryptFile(String filename, String aeskey) throws Exception {
		InputStream zipInputStream = new FileInputStream(new File("D:\\11111\\PVBFM\\FileList\\" + filename));
		Cipher cipher = AesHelper.getDecryptCipher(aeskey);
		CipherInputStream cipherInputStream = new CipherInputStream(zipInputStream, cipher);
		ZipInputStream decryptZipInputStream = new ZipInputStream(cipherInputStream);
		if (decryptZipInputStream.getNextEntry() == null) {
			return;
		}
		FileOutputStream fileOutputStream = new FileOutputStream(new File("D:\\11111\\PVBFM\\FileList\\" + filename));
		BufferedInputStream bis = new BufferedInputStream(decryptZipInputStream);
		BufferedOutputStream bos = new BufferedOutputStream(fileOutputStream);
		byte[] bytes = new byte[1024];
		int len = 0;
		while ((len = bis.read(bytes)) != -1) {
			bos.write(bytes, 0, len);
		}
		bos.flush();
		bos.close();
		bis.close();
		fileOutputStream.close();
		decryptZipInputStream.close();
		cipherInputStream.close();
		zipInputStream.close();
	}

	public static String getEncFileKey() {
		FileReader reader = null;
		String string = null;
		try {
			reader = new FileReader("D:\\11111\\PVBFM\\PP\\SK\\EncFileKey.txt");
			char[] buffer = new char[1024];
			StringBuilder builder = new StringBuilder();
			int count;
			while ((count = reader.read(buffer)) != -1) {
				builder.append(buffer, 0, count);
			}
			string = builder.toString();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return string;
	}

	public static void encFileList(ArrayList<String> fileList, LinkedHashMap<Long, Long> countmap) {
		for (String string : fileList) {
			try {
				encryptFile(string, string + FileUtils.getFileTag(string) + countmap.get(FileUtils.getFileTag(string)));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void decFileList(ArrayList<String> fileList, LinkedHashMap<Long, Long> countmap) {
		for (String string : fileList) {
			try {
				decryptFile(string, string + FileUtils.getFileTag(string) + countmap.get(FileUtils.getFileTag(string)));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
