package com.wzy.enc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

import org.junit.Test;

import com.wzy.hash.HashUtils;

public class FileUtils {

	public static ArrayList<String> getFileList(String path) {
		ArrayList<String> filenameList = new ArrayList<>();
		// get file list where the path has
		File file = new File(path);
		// get the folder list
		File[] array = file.listFiles();

		for (int i = 0; i < array.length; i++) {
			if (array[i].isFile()) {
				// only take file name
				String name = array[i].getName();
				// int indexOf = name.indexOf(".");
				// String substring = name.substring(0, indexOf);
				// filenameList.add(substring);
				filenameList.add(name);
			}
		}
		return filenameList;
	}

	public static String getFileTagKey() {
		FileReader reader = null;
		String string = null;
		try {
			reader = new FileReader("D:\\11111\\PVBFM\\PP\\SK\\KeyTag.txt");
			char[] buffer = new char[1024];
			StringBuilder builder = new StringBuilder();
			int count;
			while ((count = reader.read(buffer)) != -1) {
				builder.append(buffer, 0, count);
			}
			string = builder.toString();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return string;
	}

	public static ArrayList<Long> getFileTagList(String path) {
		String fileTagKey = getFileTagKey();
		ArrayList<Long> FileTagList = new ArrayList<>();
		ArrayList<String> fileList = getFileList(path);
		for (String string : fileList) {
			FileTagList.add(getFileTag(string));
		}
		return FileTagList;

	}

	public static long getFileTag(String filename) {
		String fileTagKey = getFileTagKey();
		long fileTag = HashUtils.RSHash(filename + fileTagKey);
		return fileTag;

	}

	public static ArrayList<String> getFullFileList(String path) {
		ArrayList<String> filenameList = new ArrayList<>();
		// get file list where the path has
		File file = new File(path);
		// get the folder list
		File[] array = file.listFiles();

		for (int i = 0; i < array.length; i++) {
			if (array[i].isFile()) {
				// only take file name
				String name = array[i].getName();

				filenameList.add(name);
			}
		}
		return filenameList;
	}

	public static void deleteFile(String filename) {
		String del = "D:\\11111\\PVBFM\\EncFileList\\" + filename;
		File delfile = new File(del);
		delfile.delete();
	}

	public static void copyFile(String oldPath, String newPath) {
		try {
			int bytesum = 0;
			int byteread = 0;
			File oldfile = new File(oldPath);
			if (oldfile.exists()) { // 鏂囦欢瀛樺湪鏃�
				InputStream inStream = new FileInputStream(oldPath); // 璇诲叆鍘熸枃浠�
				FileOutputStream fs = new FileOutputStream(newPath);
				byte[] buffer = new byte[1444];
				int length;
				while ((byteread = inStream.read(buffer)) != -1) {
					bytesum += byteread; // 瀛楄妭鏁� 鏂囦欢澶у皬
					System.out.println(bytesum);
					fs.write(buffer, 0, byteread);
				}
				inStream.close();
			}
		} catch (Exception e) {
			System.out.println("澶嶅埗鍗曚釜鏂囦欢鎿嶄綔鍑洪敊");
			e.printStackTrace();

		}

	}

	public static void copyFileUsingFileChannels(String source, String dest) {
		File oldfile = new File(source);
		File newfile = new File(dest);
		FileChannel inputChannel = null;
		FileChannel outputChannel = null;
		try {
			try {
				inputChannel = new FileInputStream(source).getChannel();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				outputChannel = new FileOutputStream(dest).getChannel();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				outputChannel.transferFrom(inputChannel, 0, inputChannel.size());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} finally {
			try {
				inputChannel.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				outputChannel.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Test
	public void test() {
	
		copyFileUsingFileChannels("D:\\11111\\PVBFM\\ICF\\icfA.txt", "D:\\11111\\PVBFM\\ICF\\prev\\icfA.txt");

	}
}
