package com.wzy.hmac;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import com.wzy.enc.FileUtils;
import com.wzy.wr.ReadFile;

public class HMACUtil {
	private static final String MAC_NAME = "HmacSHA1";
	private static final String ENCODING = "UTF-8";

	/**
	 * 使用 HMAC-SHA1 签名方法对对encryptText进行签名
	 * 
	 * @param encryptText
	 *            被签名的字符串
	 * @param encryptKey
	 *            密钥
	 * @return
	 * @throws Exception
	 */
	public static byte[] HmacSHA1Encrypt(String encryptText, String encryptKey) {
		byte[] data = null;
		try {
			data = encryptKey.getBytes(ENCODING);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 根据给定的字节数组构造一个密钥,第二参数指定一个密钥算法的名称
		SecretKey secretKey = new SecretKeySpec(data, MAC_NAME);
		// 生成一个指定 Mac 算法 的 Mac 对象
		Mac mac = null;
		try {
			mac = Mac.getInstance(MAC_NAME);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 用给定密钥初始化 Mac 对象
		try {
			mac.init(secretKey);
		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		byte[] text = null;
		try {
			text = encryptText.getBytes(ENCODING);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 完成 Mac 操作
		return mac.doFinal(text);
	}

	public static void WriteHMACTOFile(byte[] b, String hmacfilename) {
		// 1.创建目标路径
		File file = new File("D:\\11111\\PVBFM\\EncFileList\\mac\\hmac-" + hmacfilename);
		// 2.创建流通道
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 3.创建对象输出流
		ObjectOutputStream objOP = null;
		try {
			objOP = new ObjectOutputStream(fos);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 4.创建类对象，并初始化
		// SecretKey sk = generateKey();
		// 5.向目标路径文件写入对象
		try {
			objOP.writeObject(b);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 6.关闭资源
		try {
			objOP.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static byte[] ReadHMACFromFile(String hmacfilename) {
		File file = new File("D:\\11111\\PVBFM\\EncFileList\\mac\\hmac-" + hmacfilename);
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObjectInputStream objIP = null;
		try {
			objIP = new ObjectInputStream(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 读取对象数据，需要将对象流强制转换为 要写入对象的类型
		byte[] sk = null;
		try {
			sk = (byte[]) objIP.readObject();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			objIP.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sk;
	}

	public static String getHMACKey() {
		FileReader reader = null;
		String string = null;
		try {
			reader = new FileReader("D:\\11111\\PVBFM\\PP\\SK\\HMACKey.txt");
			char[] buffer = new char[1024];
			StringBuilder builder = new StringBuilder();
			int count;
			while ((count = reader.read(buffer)) != -1) {
				builder.append(buffer, 0, count);
			}
			string = builder.toString();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return string;
	}

	public static void PVFMMAC(LinkedHashMap<Long, Long> countmap, ArrayList<String> filelist) {
		for (String string : filelist) {
			String path = "D:\\11111\\PVBFM\\EncFileList\\" + string;
			String read = ReadFile.Read(path);
			long fileTag = FileUtils.getFileTag(string);
			Long long1 = countmap.get(fileTag);
			String macString = read + long1.toString();
			byte[] hmacSHA1Encrypt = HMACUtil.HmacSHA1Encrypt(macString, HMACUtil.getHMACKey());
			HMACUtil.WriteHMACTOFile(hmacSHA1Encrypt, string);
		}
	}

	public static boolean CompareByteArray(byte[] A, byte[] B) {
		if (A.length != B.length) {
			return false;
		}
		if (A.length == B.length) {
			for (int i = 0; i < B.length; i++) {
				if (A[i] != B[i]) {
					return false;
				}
			}
			return true;
		}
		return false;

	}

	public static boolean PVFMCompareMAC(LinkedHashMap<Long, Long> countmap, ArrayList<String> filelist) {
		for (String string : filelist) {
			String path = "D:\\11111\\PVBFM\\EncFileList\\" + string;
			String read = ReadFile.Read(path);
			long fileTag = FileUtils.getFileTag(string);
			Long long1 = countmap.get(fileTag);
			String macString = read + long1.toString();
			byte[] hmacSHA1Encrypt = HMACUtil.HmacSHA1Encrypt(macString, HMACUtil.getHMACKey());
			byte[] readHMACFromFile = HMACUtil.ReadHMACFromFile(string);
			//System.out.println(CompareByteArray(hmacSHA1Encrypt, readHMACFromFile));
			if (CompareByteArray(hmacSHA1Encrypt, readHMACFromFile) == false) {
				return false;
			}

		}
		return true;
	}

}
