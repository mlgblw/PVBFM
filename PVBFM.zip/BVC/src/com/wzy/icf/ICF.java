package com.wzy.icf;

import java.io.Serializable;

public class ICF implements Serializable {
	/**
	 * 	ICF表的操作，
	 * 插入，删除，验证存储等式，计算id对应值，查找值是否存在
	 * 展示存的信息，统计存的值的个数，
	 */
	private static final long serialVersionUID = 265L;
	public int m = 200;
	public int n = 9999;
	public long[] count = new long[m];
	public long[] x = new long[m];
	public long[] g = new long[m];

	public void insert(long x, int id) {
		count[id - 1] += 1;
		this.x[id - 1] += x;
		g[id - 1] += g(x);
	}

	public void clear(int id) {
		count[id - 1] = 0;
		x[id - 1] = 0;
		g[id - 1] = 0;
	}

	public int getidofx(long filed) {
		int j = 0;
		int z = 0;
		for (int i = 0; i < x.length; i++) {
			if (count[i] != 0 && filed == (x[i] / count[i])) {
				j = i;
				z++;
				break;
			}
		}
		if (z == 0) {
			return 0;
		}
		return j + 1;
	}

	public long getx(int id) {
		return (x[id - 1] / count[id - 1]);

	}

	public boolean contain(long filed) {
		int z = 0;
		for (int i = 0; i < x.length; i++) {
			if (count[i] != 0 && filed == (x[i] / count[i])) {
				z++;
				break;
			}
		}
		if (z == 0) {
			return false;
		}
		return true;
	}

	public void show() {
		System.out.println("------------");
		System.out.println("count: " + countofCCF());
		for (int i = 0; i < count.length; i++) {
			System.out
					.println("id:" + (i + 1) + "\t\t\t\t\t\t count:" + count[i] + "\t\t\t\t\t\t x:" + x[i] + "\t\t\t\t\t\t g(x):" + g[i]);
		}
	}

	public long countofCCF() {
		long j = 0;
		for (int i = 0; i < count.length; i++) {
			j = j + count[i];
		}
		return j;
	}

	public long g(Long x) {
		return (x * 55 * 31) % (n * n * n);
	}
}
