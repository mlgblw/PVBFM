package com.wzy.pvfm;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.wzy.bvc.BVC;
import com.wzy.bvc.PP;
import com.wzy.enc.EncryFileUtil;
import com.wzy.enc.FileUtils;
import com.wzy.hmac.HMACUtil;
import com.wzy.icf.ICF;
import com.wzy.icf.ICFUtils;
import com.wzy.wr.ReadAndWriteUtilis;

import it.unisa.dia.gas.jpbc.Element;

public class PVFM {
	public static void setup(int q) {
		// PP.writrgabtoFile(q);
		// PP.writrgatoFile(q);
		// PP.writrgbtoFile(q);
		ICF icfA = new ICF();
		ICF icfB = new ICF();
		ICFUtils.writeICF(icfA, "icfA");
		ICFUtils.writeICF(icfB, "icfB");
		long[] M = new long[q];
		for (int i = 0; i < q; i++) {
			M[i] = 0;
		}
		Element com = BVC.Com(M, q);
		byte[] bytes = com.toBytes();
		try {
			ReadAndWriteUtilis.writeCom(bytes, "ComA");
			ReadAndWriteUtilis.writeCom(bytes, "ComB");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(com);
	}

	public static ArrayList<Long> requestgen(String path) {
		// path = "D:\\PVBFM\\FileList";
		ArrayList<String> fileList = FileUtils.getFileList(path);
		ArrayList<Long> tagList = new ArrayList<>();
		for (String string : fileList) {
			tagList.add(FileUtils.getFileTag(string));
		}
		return tagList;
	}

	public static ArrayList<Long> requestgen(ArrayList<String> fileList) {
		// path = "D:\\PVBFM\\FileList";
		ArrayList<Long> tagList = new ArrayList<>();
		for (String string : fileList) {
			tagList.add(FileUtils.getFileTag(string));
		}
		return tagList;
	}

	public static Response responseUpload(ArrayList<String> filelist, ArrayList<String> fArrayList, ArrayList<Long> tag,
			int q) {
		FileUtils.copyFileUsingFileChannels("D:\\11111\\PVBFM\\ICF\\icfA.txt", "D:\\11111\\PVBFM\\ICF\\prev\\icfA.txt");
		FileUtils.copyFileUsingFileChannels("D:\\11111\\PVBFM\\ICF\\icfB.txt", "D:\\11111\\PVBFM\\ICF\\prev\\icfB.txt");
		Response response = new Response();
		ICF tempA = ICFUtils.readICF("icfA");
		ICF tempB = ICFUtils.readICF("icfB");
		ICF icfA = ICFUtils.readICF("icfA");
		ICF icfB = ICFUtils.readICF("icfB");
		long[] filed = new long[tag.size()];
		for (int i = 0; i < filed.length; i++) {
			filed[i] = tag.get(i);
		}
		for (int i = 0; i < filed.length; i++) {
			int insert = ICFUtils.insert(icfA, icfB, filed[i]);
			if (insert == 1) {
				ICFUtils.writeICF(icfA, "icfA");
				ICFUtils.writeICF(icfB, "icfB");
			}
			if (insert == 0) {
				fArrayList.add(filelist.get(i));
			}
		}
		for (String string : fArrayList) {
			System.out.print(string + " ");
		}
		ICFUtils.changAToB(tempB, icfB, tempA, response.IAB, response.tagB, response.DSB, response.IB, response.OB);
		ICFUtils.changBToA(tempA, icfA, tempB, response.IBA, response.tagA, response.DSA, response.IA, response.OA);

		long[] MA = new long[q];
		for (int i = 0; i < MA.length; i++) {
			MA[i] = tempA.g[i];
		}
		long[] MB = new long[q];
		for (int i = 0; i < MB.length; i++) {
			MB[i] = tempB.g[i];
		}
		if (response.IA.size() != 0) {
			int[] IA = new int[response.IA.size()];
			for (int i = 0; i < IA.length; i++) {
				IA[i] = response.IA.get(i);
			}
			Element ProofA = BVC.BatchOpen(MA, IA, q);
			response.proofMap.put("ProofA", ProofA);
		}
		if (response.IA.size() == 0) {
			response.proofMap.put("ProofA", null);
		}

		if (response.IB.size() != 0) {
			int[] IB = new int[response.IB.size()];
			for (int i = 0; i < IB.length; i++) {
				IB[i] = response.IB.get(i);
			}
			Element ProofB = BVC.BatchOpen(MB, IB, q);
			response.proofMap.put("ProofB", ProofB);
		}
		if (response.IB.size() == 0) {
			response.proofMap.put("ProofB", null);
		}

		if (response.IAB.size() != 0) {
			int[] IA1 = new int[response.IAB.size()];
			for (int i = 0; i < response.IAB.size(); i++) {
				IA1[i] = response.IAB.get(i)[0];
			}
			Element ProofA1 = BVC.BatchOpen(MA, IA1, q);
			response.proofMap.put("ProofA1", ProofA1);
		}
		if (response.IAB.size() == 0) {

			response.proofMap.put("ProofA1", null);
		}

		if (response.IBA.size() != 0) {
			int[] IB1 = new int[response.IBA.size()];
			for (int i = 0; i < response.IBA.size(); i++) {
				IB1[i] = response.IBA.get(i)[0];
			}
			Element ProofB1 = BVC.BatchOpen(MB, IB1, q);
			response.proofMap.put("ProofB1", ProofB1);
		}
		if (response.IBA.size() == 0) {

			response.proofMap.put("ProofB1", null);
		}

		return response;
	}

	public static ResponseDel responseDel(ArrayList<String> filelist, ArrayList<Long> tag, int q) {
		ResponseDel responseDel = new ResponseDel();
		ICF icfA = ICFUtils.readICF("icfA");
		ICF icfB = ICFUtils.readICF("icfB");
		ICFUtils.findInA(icfA, tag, responseDel.tagA, responseDel.IA, responseDel.DSA, responseDel.countA);
		ICFUtils.findInB(icfB, tag, responseDel.tagB, responseDel.IB, responseDel.DSB, responseDel.countB);
		long[] MA = new long[q];
		for (int i = 0; i < MA.length; i++) {
			MA[i] = icfA.g[i];
		}
		long[] MB = new long[q];
		for (int i = 0; i < MB.length; i++) {
			MB[i] = icfB.g[i];
		}
		if (responseDel.IA.size() != 0) {
			int[] IA = new int[responseDel.IA.size()];
			for (int i = 0; i < IA.length; i++) {
				IA[i] = responseDel.IA.get(i);
			}
			Element ProofA = BVC.BatchOpen(MA, IA, q);
			responseDel.proofMap.put("ProofA", ProofA);
		}
		if (responseDel.IA.size() == 0) {
			responseDel.proofMap.put("ProofA", null);
		}

		if (responseDel.IB.size() != 0) {
			int[] IB = new int[responseDel.IB.size()];
			for (int i = 0; i < IB.length; i++) {
				IB[i] = responseDel.IB.get(i);
			}
			Element ProofB = BVC.BatchOpen(MB, IB, q);
			responseDel.proofMap.put("ProofB", ProofB);
		}
		if (responseDel.IB.size() == 0) {
			responseDel.proofMap.put("ProofB", null);
		}
		return responseDel;

	}

	public static ResponseDel responseDownLoad(ArrayList<String> filelist, ArrayList<Long> tag, int q) {
		ResponseDel responseDel = new ResponseDel();
		ICF icfA = ICFUtils.readICF("icfA");
		ICF icfB = ICFUtils.readICF("icfB");
		ICFUtils.findInA(icfA, tag, responseDel.tagA, responseDel.IA, responseDel.DSA, responseDel.countA);
		ICFUtils.findInB(icfB, tag, responseDel.tagB, responseDel.IB, responseDel.DSB, responseDel.countB);
		long[] MA = new long[q];
		for (int i = 0; i < MA.length; i++) {
			MA[i] = icfA.g[i];
		}
		long[] MB = new long[q];
		for (int i = 0; i < MB.length; i++) {
			MB[i] = icfB.g[i];
		}
		if (responseDel.IA.size() != 0) {
			int[] IA = new int[responseDel.IA.size()];
			for (int i = 0; i < IA.length; i++) {
				IA[i] = responseDel.IA.get(i);
			}
			Element ProofA = BVC.BatchOpen(MA, IA, q);
			responseDel.proofMap.put("ProofA", ProofA);
		}
		if (responseDel.IA.size() == 0) {
			responseDel.proofMap.put("ProofA", null);
		}

		if (responseDel.IB.size() != 0) {
			int[] IB = new int[responseDel.IB.size()];
			for (int i = 0; i < IB.length; i++) {
				IB[i] = responseDel.IB.get(i);
			}
			Element ProofB = BVC.BatchOpen(MB, IB, q);
			responseDel.proofMap.put("ProofB", ProofB);
		}
		if (responseDel.IB.size() == 0) {
			responseDel.proofMap.put("ProofB", null);
		}
		return responseDel;

	}

	public static void batchupload(Response response, int q, ArrayList<String> filelist, ArrayList<String> fArrayList) {
		// FileUtils.copyFileUsingFileChannels("D:\\PVBFM\\ICF\\icfA.txt",
		// "D:\\PVBFM\\ICF\\prev\\icfA.txt");
		// FileUtils.copyFileUsingFileChannels("D:\\PVBFM\\ICF\\icfB.txt",
		// "D:\\PVBFM\\ICF\\prev\\icfB.txt");
		ICF previcfA = ICFUtils.readICF("prev\\icfA");
		ICF previcfB = ICFUtils.readICF("prev\\icfB");
		ICF icfA = ICFUtils.readICF("icfA");
		ICF icfB = ICFUtils.readICF("icfB");
		byte[] A = null;
		try {
			A = ReadAndWriteUtilis.readCom("ComA");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		byte[] B = null;
		try {
			B = ReadAndWriteUtilis.readCom("ComB");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element ComA = PP.G1.newElementFromBytes(A);
		Element ComB = PP.G1.newElementFromBytes(B);
		long[] MA = new long[q];
		for (int i = 0; i < MA.length; i++) {
			MA[i] = previcfA.g[i];
		}
		long[] MB = new long[q];
		for (int i = 0; i < MB.length; i++) {
			MB[i] = previcfB.g[i];
		}
		if (response.IA.size() != 0) {
			int[] IA = new int[response.IA.size()];
			for (int i = 0; i < IA.length; i++) {
				IA[i] = response.IA.get(i);
			}
			Element ProofA = response.proofMap.get("ProofA");
			BVC.BatchVer(ComA, MA, IA, ProofA, q);
		}

		if (response.IB.size() != 0) {
			int[] IB = new int[response.IB.size()];
			for (int i = 0; i < IB.length; i++) {
				IB[i] = response.IB.get(i);
			}
			Element ProofB = response.proofMap.get("ProofB");
			BVC.BatchVer(ComB, MB, IB, ProofB, q);
		}

		if (response.IAB.size() != 0) {
			int[] IA1 = new int[response.IAB.size()];
			for (int i = 0; i < response.IAB.size(); i++) {
				IA1[i] = response.IAB.get(i)[0];
			}
			Element ProofA1 = response.proofMap.get("ProofA1");
			BVC.BatchVer(ComA, MA, IA1, ProofA1, q);
		}

		if (response.IBA.size() != 0) {
			int[] IB1 = new int[response.IBA.size()];
			for (int i = 0; i < response.IBA.size(); i++) {
				IB1[i] = response.IBA.get(i)[0];
			}
			Element ProofB1 = response.proofMap.get("ProofB1");
			BVC.BatchVer(ComB, MB, IB1, ProofB1, q);
		}
		ArrayList<Long> AhashSum = new ArrayList<>();
		ArrayList<Integer> Aweizhi = new ArrayList<>();
		for (int i = 0; i < MA.length; i++) {
			if (icfA.g[i] != previcfA.g[i]) {
				AhashSum.add(icfA.g[i] - previcfA.g[i]);
				Aweizhi.add(i + 1);
			}
		}
		if (AhashSum.size() != 0) {
			long[] hashSumA = new long[AhashSum.size()];
			for (int i = 0; i < AhashSum.size(); i++) {
				hashSumA[i] = AhashSum.get(i);
			}
			int[] weizhiA = new int[Aweizhi.size()];
			for (int i = 0; i < Aweizhi.size(); i++) {
				weizhiA[i] = Aweizhi.get(i);
			}
			Element batchUpd = BVC.BatchUpd(ComA, weizhiA, hashSumA, q);
			System.out.println(batchUpd);
			byte[] bytes = batchUpd.toBytes();
			try {
				ReadAndWriteUtilis.writeCom(bytes, "ComA");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		ArrayList<Long> BhashSum = new ArrayList<>();
		ArrayList<Integer> Bweizhi = new ArrayList<>();
		for (int i = 0; i < MB.length; i++) {
			if (icfB.g[i] != previcfB.g[i]) {
				BhashSum.add(icfB.g[i] - previcfB.g[i]);
				Bweizhi.add(i + 1);
			}
		}
		if (BhashSum.size() != 0) {
			long[] hashSumB = new long[BhashSum.size()];
			for (int i = 0; i < BhashSum.size(); i++) {
				hashSumB[i] = BhashSum.get(i);
			}
			int[] weizhiB = new int[Bweizhi.size()];
			for (int i = 0; i < Bweizhi.size(); i++) {
				weizhiB[i] = Bweizhi.get(i);
			}
			Element batchUpd = BVC.BatchUpd(ComB, weizhiB, hashSumB, q);
			byte[] bytes = batchUpd.toBytes();
			System.out.println(batchUpd);
			try {
				ReadAndWriteUtilis.writeCom(bytes, "ComB");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (fArrayList.size() != 0) {
			for (int i = 0; i < fArrayList.size(); i++) {
				filelist.remove(fArrayList.get(i));
			}
		}

		LinkedHashMap<Long, Long> countmap = new LinkedHashMap<>();
		for (int i = 0; i < filelist.size(); i++) {
			int findA = ICFUtils.findA(icfA, FileUtils.getFileTag(filelist.get(i)));
			int findB = ICFUtils.findB(icfB, FileUtils.getFileTag(filelist.get(i)));
			if (findA != 0) {
				countmap.put(FileUtils.getFileTag(filelist.get(i)), icfA.count[findA - 1]);
			}
			if (findB != 0) {
				countmap.put(FileUtils.getFileTag(filelist.get(i)), icfB.count[findB - 1]);
			}
		}
		EncryFileUtil.encFileList(filelist, countmap);
		HMACUtil.PVFMMAC(countmap, filelist);
	}

	public static void batchDownload(ResponseDel responseDown, ArrayList<String> filelist, int q) {
		ICF icfA = ICFUtils.readICF("icfA");
		ICF icfB = ICFUtils.readICF("icfB");
		byte[] A = null;
		try {
			A = ReadAndWriteUtilis.readCom("ComA");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		byte[] B = null;
		try {
			B = ReadAndWriteUtilis.readCom("ComB");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element ComA = PP.G1.newElementFromBytes(A);
		Element ComB = PP.G1.newElementFromBytes(B);
		long[] MA = new long[q];
		for (int i = 0; i < MA.length; i++) {
			MA[i] = icfA.g[i];
		}
		long[] MB = new long[q];
		for (int i = 0; i < MB.length; i++) {
			MB[i] = icfB.g[i];
		}
		if (responseDown.IA.size() != 0) {
			int[] IA = new int[responseDown.IA.size()];
			for (int i = 0; i < IA.length; i++) {
				IA[i] = responseDown.IA.get(i);
			}
			Element ProofA = responseDown.proofMap.get("ProofA");
			BVC.BatchVer(ComA, MA, IA, ProofA, q);

		}

		if (responseDown.IB.size() != 0) {
			int[] IB = new int[responseDown.IB.size()];
			for (int i = 0; i < IB.length; i++) {
				IB[i] = responseDown.IA.get(i);
			}
			Element ProofB = responseDown.proofMap.get("ProofB");
			BVC.BatchVer(ComB, MB, IB, ProofB, q);
		}
		LinkedHashMap<Long, Long> countmap = new LinkedHashMap<>();
		if (responseDown.countA.size() != 0) {
			for (int i = 0; i < responseDown.countA.size(); i++) {
				countmap.put(responseDown.tagA.get(i), responseDown.countA.get(i));
			}
		}
		if (responseDown.countB.size() != 0) {
			for (int i = 0; i < responseDown.countB.size(); i++) {
				countmap.put(responseDown.tagB.get(i), responseDown.countB.get(i));
			}
		}
		HMACUtil.PVFMCompareMAC(countmap, filelist);
		EncryFileUtil.decFileList(filelist, countmap);

	}

	public static void batchdel(ResponseDel responseDel, ArrayList<String> filelist, int q) {
		ICF icfA = ICFUtils.readICF("icfA");
		ICF icfB = ICFUtils.readICF("icfB");
		byte[] A = null;
		try {
			A = ReadAndWriteUtilis.readCom("ComA");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		byte[] B = null;
		try {
			B = ReadAndWriteUtilis.readCom("ComB");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element ComA = PP.G1.newElementFromBytes(A);
		Element ComB = PP.G1.newElementFromBytes(B);
		long[] MA = new long[q];
		for (int i = 0; i < MA.length; i++) {
			MA[i] = icfA.g[i];
		}
		long[] MB = new long[q];
		for (int i = 0; i < MB.length; i++) {
			MB[i] = icfB.g[i];
		}
		if (responseDel.IA.size() != 0) {
			int[] IA = new int[responseDel.IA.size()];
			for (int i = 0; i < IA.length; i++) {
				IA[i] = responseDel.IA.get(i);
			}

			long[] SUA = new long[responseDel.IA.size()];
			for (int i = 0; i < SUA.length; i++) {
				SUA[i] = -MA[IA[i]];
			}

			Element ProofA = responseDel.proofMap.get("ProofA");
			int batchVer = BVC.BatchVer(ComA, MA, IA, ProofA, q);
			Element batchUpd = BVC.BatchUpd(ComA, IA, SUA, q);
			byte[] bytes = batchUpd.toBytes();
			try {
				ReadAndWriteUtilis.writeCom(bytes, "ComA");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			for (int i = 0; i < IA.length; i++) {
				ICFUtils.deletebyId(icfA, IA[i]);
				ICFUtils.writeICF(icfA, "icfA");
			}
		}
		if (responseDel.IB.size() != 0) {
			int[] IB = new int[responseDel.IB.size()];
			for (int i = 0; i < IB.length; i++) {
				IB[i] = responseDel.IB.get(i);
			}
			
			long[] SUB = new long[responseDel.IB.size()];
			for (int i = 0; i < SUB.length; i++) {
				SUB[i] = -MB[IB[i]];
			}
			
			Element ProofB = responseDel.proofMap.get("ProofB");
			int batchVer = BVC.BatchVer(ComB, MB, IB, ProofB, q);
			
			Element batchUpd = BVC.BatchUpd(ComB, IB, SUB, q);
			byte[] bytes = batchUpd.toBytes();
			try {
				ReadAndWriteUtilis.writeCom(bytes, "ComB");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			for (int i = 0; i < IB.length; i++) {
				ICFUtils.deletebyId(icfB, IB[i]);
				ICFUtils.writeICF(icfB, "icfB");
			}
		}
		for (String filename : filelist) {
			FileUtils.deleteFile(filename);
		}
	}

}
