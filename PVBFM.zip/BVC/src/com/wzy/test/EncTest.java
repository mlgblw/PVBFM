package com.wzy.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.junit.Test;

import com.wzy.enc.EncryFileUtil;
import com.wzy.enc.FileUtils;

public class EncTest {

	@Test
	public void test() {
		String path = "D:\\11111\\PVBFM\\FileList";
		LinkedHashMap<Long, Long> countmap = new LinkedHashMap<>();
		ArrayList<String> fileList = FileUtils.getFileList(path);

		for (String string : fileList) {
			countmap.put(FileUtils.getFileTag(string), (long) 1);
//			EncryFileUtil.encryptFile(string,);

		}
//		EncryFileUtil.encryptFile(countmap);
		EncryFileUtil.decFileList(fileList, countmap);

	}
}
