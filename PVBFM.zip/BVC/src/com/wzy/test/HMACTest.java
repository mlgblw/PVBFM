package com.wzy.test;

import org.junit.Test;

import com.wzy.hmac.HMACUtil;
import com.wzy.wr.ReadFile;

public class HMACTest {
	@Test
	public void test() {
		String filepath = "D:\\11111\\HMAC\\hh.docx";
		String read = ReadFile.Read(filepath);
		byte[] hmacSHA1Encrypt = HMACUtil.HmacSHA1Encrypt(read, HMACUtil.getHMACKey());
		byte[] hmacSHA1Encrypt1 = HMACUtil.HmacSHA1Encrypt(read, HMACUtil.getHMACKey());
		for (byte b : hmacSHA1Encrypt) {
			System.out.print(b);
		}
		System.out.println();
		System.out.println(CompareByteArray(hmacSHA1Encrypt, hmacSHA1Encrypt1));
		// HMACUtil.WriteHMACTOFile(hmacSHA1Encrypt, "hh");
		// byte[] readHMACFromFile = HMACUtil.ReadHMACFromFile("hh");
		// for (byte b : readHMACFromFile) {
		// System.out.print(b);
		// }

	}

	public static boolean CompareByteArray(byte[] A, byte[] B) {
		if (A.length != B.length) {
			return false;
		}
		if (A.length == B.length) {
			for (int i = 0; i < B.length; i++) {
				if (A[i] != B[i]) {
					return false;
				}
			}
			return true;
		}
		return false;

	}

}
