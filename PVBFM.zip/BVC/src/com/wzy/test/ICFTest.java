package com.wzy.test;

import java.util.ArrayList;

import org.junit.Test;

import com.wzy.icf.ICF;
import com.wzy.icf.ICFUtils;
import com.wzy.pvfm.PVFM;

public class ICFTest {
	@Test
	public void test() {
		ICF icfA = ICFUtils.readICF("icfA");
		ICF icfB = ICFUtils.readICF("icfB");
		String path = "D:\\11111\\PVBFM\\FileList";
		ArrayList<Long> requestgen = PVFM.requestgen(path);
		long filed[] = new long[requestgen.size()];
		for (int i = 0; i < filed.length; i++) {
			filed[i] = requestgen.get(i);
		}
		// int filed[] = new int[] { 1, 2, 3, 4, 5, 6, 12, 12, 34, 56, 87, 90, 123, 123,
		// 230, 356, 456, 456, 666, 666, 789,
		// 900, 1000, 2000, 3000, 3200, 7555 };
		System.out.println(filed.length);
		ArrayList<Long> fArrayList = new ArrayList<>();
		for (int i = 0; i < filed.length; i++) {
			int insert = ICFUtils.insert(icfA, icfB, filed[i]);
			if (insert == 1) {
				ICFUtils.writeICF(icfA, "icfA");
				ICFUtils.writeICF(icfB, "icfB");
			}
			if (insert == 0) {
				fArrayList.add(filed[i]);
			}
		}

		icfA.show();
		icfB.show();
		System.out.println("------------");
		System.out.println(fArrayList);

	}

	@Test
	public void test1() {
		ICF icfA = new ICF();
		ICF icfB = new ICF();
		ICFUtils.writeICF(icfA, "icfA");
		ICFUtils.writeICF(icfB, "icfB");

	}

	@Test
	public void test2() {
		ICF icfA = ICFUtils.readICF("icfA");
		ICF icfB = ICFUtils.readICF("icfB");
		icfA.show();
		icfB.show();
	}

	@Test
	public void pub() {
		ICF icfA = ICFUtils.readICF("icfA");
		ICF icfB = ICFUtils.readICF("icfB");
		int delete = ICFUtils.delete(icfA, 2000);
		int delete1 = ICFUtils.delete(icfB, 123);
		System.out.println(delete);
		System.out.println(delete1);
	}
}
