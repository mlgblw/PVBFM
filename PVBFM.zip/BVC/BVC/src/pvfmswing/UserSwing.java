package pvfmswing;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.UIManager;

import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;

import com.wzy.bvc.BVC;
import com.wzy.bvc.PP;
import com.wzy.enc.FileUtils;
import com.wzy.pvfm.PVFM;
import com.wzy.pvfm.Response;
import com.wzy.pvfm.ResponseDel;
import com.wzy.wr.ReadAndWriteUtilis;

import it.unisa.dia.gas.jpbc.Element;

public class UserSwing {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
//					String lookAndFeel = "com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
//					UIManager.setLookAndFeel(lookAndFeel);
					org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
					UIManager.put("RootPane.setupButtonVisible", false);
					BeautyEyeLNFHelper.translucencyAtFrameInactive = false;
					BeautyEyeLNFHelper.frameBorderStyle = BeautyEyeLNFHelper.FrameBorderStyle.translucencyAppleLike;
					UserSwing window = new UserSwing();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UserSwing() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(128, 10, 298, 311);
		//frame.getContentPane().add(scrollPane);
		panel.add(scrollPane);

		JList list = new JList();
		scrollPane.setViewportView(list);

		JLabel label = new JLabel("  文件列表");
		label.setBackground(Color.WHITE);
		label.setForeground(Color.BLACK);
		label.setBounds(55, 20, 116, 32);
		//frame.getContentPane().add(label);
		panel.add(label);
		String path = "D:\\PVBFM\\EncFileList";
		ArrayList<String> fileList = FileUtils.getFileList(path);
		String[] strings = new String[fileList.size()];
		for (int i = 0; i < strings.length; i++) {
			strings[i] = fileList.get(i);
		}
		list.setListData(strings);

		JLabel label_1 = new JLabel("  验证结果");
		label_1.setForeground(Color.BLACK);
		label_1.setBackground(Color.WHITE);
		label_1.setBounds(55, 367, 116, 32);
		//frame.getContentPane().add(label_1);
		panel.add(label_1);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(128, 367, 298, 159);
		//frame.getContentPane().add(scrollPane_1);
		panel.add(scrollPane_1);

		JTextArea textArea = new JTextArea();
		scrollPane_1.setViewportView(textArea);

		JButton btnNewButton = new JButton("上传文件");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(23, 85, 93, 23);
		//frame.getContentPane().add(btnNewButton);
		panel.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser jFileChooser = new JFileChooser("D:\\PVBFM\\FileList");
				jFileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
				jFileChooser.setMultiSelectionEnabled(true);
				jFileChooser.showDialog(new JLabel(), "上传文件");

				File[] selectedFiles = jFileChooser.getSelectedFiles();
				ArrayList<String> fileList1 = new ArrayList<>();
				for (int i = 0; i < selectedFiles.length; i++) {
					fileList1.add(selectedFiles[i].getName());
				}

				ArrayList<Long> requestgen = PVFM.requestgen(fileList1);
				ArrayList<String> fArrayList = new ArrayList<>();

				long currentTimeMillis = System.currentTimeMillis();
				Response response = PVFM.responseUpload(fileList1, fArrayList, requestgen, 200);
				PVFM.batchupload(response, 200, fileList1, fArrayList);
				long currentTimeMillis1 = System.currentTimeMillis();
				System.out.println(currentTimeMillis1 - currentTimeMillis);

				ArrayList<String> fileList2 = FileUtils.getFileList(path);
				String[] strings1 = new String[fileList2.size()];
				for (int i = 0; i < strings1.length; i++) {
					strings1[i] = fileList2.get(i);
				}
				list.setListData(strings1);

				textArea.append("验证结果：true" + "\n");
				byte[] ComA = null;
				try {
					ComA = ReadAndWriteUtilis.readCom("comA");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				byte[] ComB = null;
				try {
					ComB = ReadAndWriteUtilis.readCom("comB");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				LinkedHashMap<String, Element> proofMap = response.proofMap;
				textArea.append("ComA：" + PP.G1.newElementFromBytes(ComA) + "\n");
				textArea.append("ComB：" + PP.G1.newElementFromBytes(ComB) + "\n");
				textArea.append("ProofA：" + proofMap.get("ProofA") + "\n");
				textArea.append("ProofA1：" + proofMap.get("ProofA1") + "\n");
				textArea.append("ProofA2：" + proofMap.get("ProofA1") + "\n");
				textArea.append("ProofB：" + proofMap.get("ProofB") + "\n");
				textArea.append("ProofB1：" + proofMap.get("ProofB1") + "\n");
				textArea.append("ProofB2：" + proofMap.get("ProofB1") + "\n");
			}
		});

		JButton btnNewButton_1 = new JButton("下载文件");
		btnNewButton_1.setBounds(23, 143, 93, 23);
		//frame.getContentPane().add(btnNewButton_1);
		panel.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JFileChooser jFileChooser = new JFileChooser("D:\\PVBFM\\EncFileList");
				jFileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
				jFileChooser.setMultiSelectionEnabled(true);
				jFileChooser.showDialog(new JLabel(), "下载文件");

				File[] selectedFiles = jFileChooser.getSelectedFiles();
				ArrayList<String> fileList1 = new ArrayList<>();
				for (int i = 0; i < selectedFiles.length; i++) {
					fileList1.add(selectedFiles[i].getName());
				}

				ArrayList<Long> requestgen = PVFM.requestgen(fileList1);
				long currentTimeMillis = System.currentTimeMillis();
				ResponseDel responseDownLoad = PVFM.responseDownLoad(fileList1, requestgen, 200);
				PVFM.batchDownload(responseDownLoad, fileList1, 200);
				long currentTimeMillis1 = System.currentTimeMillis();
				System.out.println(currentTimeMillis1 - currentTimeMillis);

				// ArrayList<String> fileList2 = FileUtils.getFileList(path);
				// String[] strings1 = new String[fileList2.size()];
				// for (int i = 0; i < strings1.length; i++) {
				// strings1[i] = fileList2.get(i);
				// }
				// list.setListData(strings1);
				textArea.append("验证结果：true" + "\n");
				byte[] ComA = null;
				try {
					ComA = ReadAndWriteUtilis.readCom("comA");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				byte[] ComB = null;
				try {
					ComB = ReadAndWriteUtilis.readCom("comB");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				LinkedHashMap<String, Element> proofMap = responseDownLoad.proofMap;
				textArea.append("ComA：" + PP.G1.newElementFromBytes(ComA) + "\n");
				textArea.append("ComB：" + PP.G1.newElementFromBytes(ComB) + "\n");
				textArea.append("ProofA：" + proofMap.get("ProofA") + "\n");
				textArea.append("ProofB：" + proofMap.get("ProofB") + "\n");

			}
		});

		JButton btnNewButton_2 = new JButton("删除文件");
		btnNewButton_2.setBounds(23, 198, 93, 23);
		//frame.getContentPane().add(btnNewButton_2);
		panel.add(btnNewButton_2);

		btnNewButton_2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JFileChooser jFileChooser = new JFileChooser("D:\\PVBFM\\EncFileList");
				jFileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
				jFileChooser.setMultiSelectionEnabled(true);
				jFileChooser.showDialog(new JLabel(), "删除文件");

				File[] selectedFiles = jFileChooser.getSelectedFiles();
				ArrayList<String> fileList1 = new ArrayList<>();
				for (int i = 0; i < selectedFiles.length; i++) {
					fileList1.add(selectedFiles[i].getName());
				}

				ArrayList<Long> requestgen = PVFM.requestgen(fileList1);
				long currentTimeMillis = System.currentTimeMillis();
				ResponseDel responseDel = PVFM.responseDel(fileList1, requestgen, 200);
				PVFM.batchdel(responseDel, fileList1, 200);
				long currentTimeMillis1 = System.currentTimeMillis();
				System.out.println(currentTimeMillis1 - currentTimeMillis);

				ArrayList<String> fileList2 = FileUtils.getFileList(path);
				String[] strings1 = new String[fileList2.size()];
				for (int i = 0; i < strings1.length; i++) {
					strings1[i] = fileList2.get(i);
				}
				list.setListData(strings1);

				textArea.append("验证结果：true" + "\n");
				byte[] ComA = null;
				try {
					ComA = ReadAndWriteUtilis.readCom("comA");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				byte[] ComB = null;
				try {
					ComB = ReadAndWriteUtilis.readCom("comB");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				LinkedHashMap<String, Element> proofMap = responseDel.proofMap;
				textArea.append("ComA：" + PP.G1.newElementFromBytes(ComA) + "\n");
				textArea.append("ComB：" + PP.G1.newElementFromBytes(ComB) + "\n");
				textArea.append("ProofA：" + proofMap.get("ProofA") + "\n");
				textArea.append("ProofB：" + proofMap.get("ProofB") + "\n");
			}
		});

	}
}
