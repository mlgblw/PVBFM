package pvfmswing;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.UIManager;

import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;
import org.junit.Test;

import com.wzy.bvc.BVC;
import com.wzy.bvc.PP;
import com.wzy.enc.EncryFileUtil;
import com.wzy.enc.FileUtils;
import com.wzy.hmac.HMACUtil;
import com.wzy.pvfm.PVFM;

import it.unisa.dia.gas.jpbc.Element;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class InitSwing {

	private JFrame frmSystemSetup;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
//					String lookAndFeel = "com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
//					UIManager.setLookAndFeel(lookAndFeel);
					org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
					UIManager.put("RootPane.setupButtonVisible", false);
					BeautyEyeLNFHelper.translucencyAtFrameInactive = false;
					BeautyEyeLNFHelper.frameBorderStyle = BeautyEyeLNFHelper.FrameBorderStyle.translucencyAppleLike;
					InitSwing window = new InitSwing();
					window.frmSystemSetup.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public InitSwing() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSystemSetup = new JFrame("系统初始化");
		frmSystemSetup.setTitle("System Setup");
		frmSystemSetup.setBounds(100, 100, 500, 660);
		frmSystemSetup.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		frmSystemSetup.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton button = new JButton("初始化");
		button.setFont(new Font("宋体", Font.PLAIN, 13));
		button.setBounds(10, 20, 93, 23);
		//frame.getContentPane().add(button);
		panel.add(button);

		textField = new JTextField();
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		textField.setBounds(113, 21, 66, 22);
		//frame.getContentPane().add(textField);
		panel.add(textField);
		textField.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 53, 464, 416);
		//frame.getContentPane().add(scrollPane);
		panel.add(scrollPane);

		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		scrollPane.setViewportView(textArea);

		JLabel lblNewLabel = new JLabel("  PP  ");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		scrollPane.setRowHeaderView(lblNewLabel);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 494, 464, 86);
		//frame.getContentPane().add(scrollPane_1);
		panel.add(scrollPane_1);

		JTextArea textArea_1 = new JTextArea();
		textArea_1.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		scrollPane_1.setViewportView(textArea_1);

		JLabel lblSk = new JLabel("  SK  ");
		lblSk.setBackground(Color.LIGHT_GRAY);
		lblSk.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		scrollPane_1.setRowHeaderView(lblSk);

		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String init = textField.getText();
				int q = Integer.parseInt(init);
				PVFM.setup(q);
				textArea.append("ga:");
				textArea.append("\n");
				LinkedHashMap<String, Element> getgaFromFile = PP.getgaFromFile(q, "ga");
				Set<Entry<String, Element>> entrySet = getgaFromFile.entrySet();
				for (Entry<String, Element> entry : entrySet) {
					textArea.append(entry.getKey() + " : " + entry.getValue());
					textArea.append("\n");

				}
				textArea.append("gb:");
				textArea.append("\n");
				LinkedHashMap<String, Element> getgbFromFile = PP.getgaFromFile(q, "gb");
				Set<Entry<String, Element>> entrySet1 = getgbFromFile.entrySet();
				for (Entry<String, Element> entry : entrySet1) {
					textArea.append(entry.getKey() + " : " + entry.getValue());
					textArea.append("\n");

				}
				textArea.append("gab:");
				textArea.append("\n");
				LinkedHashMap<String, Element> getgabFromFile = PP.getgabFromFile(q);
				Set<Entry<String, Element>> entrySet2 = getgabFromFile.entrySet();
				for (Entry<String, Element> entry : entrySet2) {
					textArea.append(entry.getKey() + " : " + entry.getValue());
					textArea.append("\n");
				}

				textArea_1.append("EncKey:  " + EncryFileUtil.getEncFileKey());
				textArea_1.append("\n");
				textArea_1.append("HMACKey:  " + HMACUtil.getHMACKey());
				textArea_1.append("\n");
				textArea_1.append("TagKey:  " + FileUtils.getFileTagKey());
				textArea_1.append("\n");
			}
		});
		


	}

	@Test
	public void test() {
		LinkedHashMap<String, Element> getgaFromFile = PP.getgaFromFile(10, "ga");
		Set<Entry<String, Element>> entrySet = getgaFromFile.entrySet();
		for (Entry<String, Element> entry : entrySet) {
			System.out.println(entry.getKey() + " : " + entry.getValue());

		}
	}
}
