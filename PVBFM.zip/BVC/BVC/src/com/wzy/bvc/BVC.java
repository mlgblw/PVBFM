package com.wzy.bvc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import com.wzy.wr.ReadAndWriteUtilis;

import it.unisa.dia.gas.jpbc.Element;

public class BVC {
	public static Element Com(long[] M, int q) {
		LinkedHashMap<String, Element> ga = PP.getgaFromFile(q, "ga");
		Element element = ga.get("ga1").pow(new BigInteger(String.valueOf(M[0])));
		for (int i = 2; i <= q; i++) {
			element = element.mul(ga.get("ga" + i).pow(new BigInteger(String.valueOf(M[i - 1]))));
		}
		return element;
	}

	public static Element BatchOpen(long[] M, int[] I, int q) {
		LinkedHashMap<String, Element> gab = PP.getgabFromFile(q);
		ArrayList<Element> proof = new ArrayList<>();
		for (int i = 0; i < I.length; i++) {
			for (int j = 1; j <= q; j++) {
				String string = "ga" + (q + j - I[i]) + "b" + I[i];
				boolean contains = string.contains("ga" + q);

//				 System.out.println(string + " " + contains);
				if (contains == false) {
					Element element = gab.get(string).pow(new BigInteger(String.valueOf(M[j - 1])));
					proof.add(element);
				}

			}
		}
		Element element = proof.get(0);
		for (int i = 1; i < proof.size(); i++) {
			element = element.mul(proof.get(i));
		}
		return element;
	}

	public static int BatchVer(Element Com, long[] M, int[] I, Element Proof, int q) {
		LinkedHashMap<String, Element> gb = PP.getgaFromFile(q, "gb");
		LinkedHashMap<String, Element> gab = PP.getgabFromFile(q);
		Element element = gb.get("gb" + I[0]).pow(new BigInteger(String.valueOf(M[I[0] - 1])));
		for (int i = 1; i < I.length; i++) {
			element = element.mul(gb.get("gb" + I[i]).pow(new BigInteger(String.valueOf(M[I[i] - 1]))));
		}
		Element element2 = gab.get("ga" + (q - I[0] + 1) + "b" + I[0]);
		Element pairing = PP.pairing.pairing(Com, element2);
		for (int i = 1; i < I.length; i++) {
			pairing = pairing.mul(PP.pairing.pairing(Com, gab.get("ga" + (q - I[i] + 1) + "b" + (I[i]))));
		}
		String name = "ga" + q;
		byte[] readElement = null;
		try {
			readElement = ReadAndWriteUtilis.readElement(name);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element gaq = PP.G1.newElementFromBytes(readElement);
		Element pairing2 = PP.pairing.pairing(element, gaq);
		Element g = PP.getg();
		Element pairing3 = PP.pairing.pairing(Proof, g);
		Element mul = pairing2.mul(pairing3);
		if (mul.equals(pairing)) {
			return 1;
		}
		return 0;

	}

	public static Element BatchUpd(Element Com, int[] I, long[] SU, int q) {
		LinkedHashMap<String, Element> ga = PP.getgaFromFile(q, "ga");
		Element pow = ga.get("ga" + (I[0])).pow(new BigInteger(String.valueOf(SU[0])));
		for (int i = 1; i < SU.length; i++) {
//			 System.out.println("ga" + (I[i]));
			pow.mul(ga.get("ga" + (I[i])).pow(new BigInteger(String.valueOf(SU[i]))));

		}
		Com = Com.mul(pow);
		return Com;
	}

	public static void writeCtoFile(byte[] b) {
		// 1.閸掓稑缂撻惄顔界垼鐠侯垰绶�
		File file = new File("D:\\11111\\PVBFM\\PVBFM1\\PP\\C.txt");
		// 2.閸掓稑缂撳ù渚�锟芥岸浜�
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 3.閸掓稑缂撶�电钖勬潏鎾冲毉濞达拷
		ObjectOutputStream objOP = null;
		try {
			objOP = new ObjectOutputStream(fos);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 4.閸掓稑缂撶猾璇差嚠鐠炩槄绱濋獮璺哄灥婵瀵�
		// SecretKey sk = generateKey();
		// 5.閸氭垹娲伴弽鍥熅瀵板嫭鏋冩禒璺哄晸閸忋儱顕挒锟�
		try {
			objOP.writeObject(b);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 6.閸忔娊妫寸挧鍕爱
		try {
			objOP.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static Element readCfromFile() {
		File file = new File("D:\\11111\\PVBFM\\PVBFM1\\PP\\C.txt");
		FileInputStream fis = null;
		byte[] sk = null;
		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObjectInputStream objIP = null;
		try {
			objIP = new ObjectInputStream(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 鐠囪褰囩�电钖勯弫鐗堝祦閿涘矂娓剁憰浣哥殺鐎电钖勫ù浣稿繁閸掓儼娴嗛幑顫礋 鐟曚礁鍟撻崗銉ヮ嚠鐠烇紕娈戠猾璇茬��
		try {
			sk = (byte[]) objIP.readObject();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println(sk);
		try {
			objIP.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element newElementFromBytes = PP.G1.newElementFromBytes(sk);
		return newElementFromBytes;
	}


}
