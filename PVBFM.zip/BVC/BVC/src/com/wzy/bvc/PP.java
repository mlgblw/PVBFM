package com.wzy.bvc;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

import org.junit.Test;

import com.wzy.wr.ReadAndWriteUtilis;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

public class PP {
	public static Pairing pairing = PairingFactory.getPairing("a.properties");
	public static Field<Element> Zr = pairing.getZr();
	public static Field<Element> G1 = pairing.getG1();
	public static Element g = G1.newRandomElement().getImmutable();
	public static Element alapha = Zr.newRandomElement().getImmutable();
	public static Element beta = Zr.newRandomElement().getImmutable();

	public Element acl(int i, Element e) {
		for (int j = 1; j <= i; j++) {
			e = e.mul(e);
		}
		return e;
	}

	public static LinkedHashMap<String, Element> getga(int q, Element gElement, Element aElement) {
		LinkedHashMap<String, Element> e = new LinkedHashMap<>();
		for (int i = 1; i <= q; i++) {
			Element powZn = gElement.duplicate().powZn(aElement.duplicate().pow(new BigInteger(String.valueOf(i))));
			// System.out.println(powZn);
			e.put("ga" + i, powZn);
			// e.add(alapha.pow(new BigInteger(String.valueOf(i))));
		}
		return e;
	}

	public static LinkedHashMap<String, Element> getgb(int q, Element gElement, Element bElement) {
		LinkedHashMap<String, Element> e = new LinkedHashMap<>();
		for (int i = 1; i <= q; i++) {
			Element powZn = gElement.duplicate().powZn(bElement.duplicate().pow(new BigInteger(String.valueOf(i))));
			e.put("gb" + i, powZn);

		}
		return e;
	}

	public static LinkedHashMap<String, Element> getgab(int q, Element gElement, Element aElement, Element bElement) {
		LinkedHashMap<String, Element> e = new LinkedHashMap<>();
		for (int i = 1; i <= (2 * q - 1); i++) {
//			if (i == q) {
//				continue;
//			}
			for (int j = 1; j <= (2 * q - 1); j++) {
//				if (j == q) {
//					continue;
//				}
				Element mul = gElement.duplicate().powZn(aElement.duplicate().pow(new BigInteger(String.valueOf(i))))
						.mul(gElement.duplicate().powZn(bElement.duplicate().pow(new BigInteger(String.valueOf(j)))));
				e.put("ga" + i + "b" + j, mul);
			}
		}
		return e;
	}

	public static Element geta() {
		String a = "a";
		byte[] ab = null;
		try {
			ab = ReadAndWriteUtilis.readElement(a);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element Elementa = Zr.newElementFromBytes(ab);
		return Elementa;
	}

	public static Element getb() {
		String b = "b";
		byte[] bb = null;
		try {
			bb = ReadAndWriteUtilis.readElement(b);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element Elementb = Zr.newElementFromBytes(bb);
		return Elementb;
	}

	public static Element getg() {
		String g = "g";
		byte[] gb = null;
		try {
			gb = ReadAndWriteUtilis.readElement(g);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element Elementg = G1.newElementFromBytes(gb);
		return Elementg;
	}

	public static LinkedHashMap<String, Element> getgaFromFile(int q, String filename) {
		LinkedHashMap<String, Element> ga = new LinkedHashMap<>();
		for (int i = 1; i <= q; i++) {
			String name = filename + i;
			byte[] readElement = null;
			try {
				readElement = ReadAndWriteUtilis.readElement(name);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Element newElementFromBytes = G1.newElementFromBytes(readElement);
			ga.put(name, newElementFromBytes);
		}
		return ga;

	}

	public static LinkedHashMap<String, Element> getgabFromFile(int q) {
		LinkedHashMap<String, Element> gab = new LinkedHashMap<>();
		for (int i = 1; i <= (2 * q - 1); i++) {
//			if (i == q) {
//				continue;
//			}
			for (int j = 1; j <= (2 * q - 1); j++) {
//				if (j == q) {
//					continue;
//				}
				String name = "ga" + i + "b" + j;
				byte[] readElement = null;
				try {
					readElement = ReadAndWriteUtilis.readElement(name);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Element newElementFromBytes = G1.newElementFromBytes(readElement);
				gab.put("ga" + i + "b" + j, newElementFromBytes);
			}
		}

		return gab;

	}

	@Test
	public void testa() throws IOException {
		byte[] bytes = alapha.toBytes();
		String nameofelement = "a";
		ReadAndWriteUtilis.writeElement(bytes, nameofelement);
	}

	@Test
	public void testb() throws IOException {
		byte[] bytes = alapha.toBytes();
		String nameofelement = "b";
		ReadAndWriteUtilis.writeElement(bytes, nameofelement);
	}

	@Test
	public void testg() throws IOException {
		byte[] bytes = g.toBytes();
		String nameofelement = "g";
		ReadAndWriteUtilis.writeElement(bytes, nameofelement);
	}

	@Test
	public void test3() throws ClassNotFoundException, IOException {
		// String a = "a";
		// byte[] ab = ReadAndWriteUtilis.readElement(a);
		// Element Elementa = Zr.newElementFromBytes(ab);
		Element geta = geta();
		System.out.println(geta);

		// String b = "b";
		// byte[] bb = ReadAndWriteUtilis.readElement(b);
		// Element Elementb = Zr.newElementFromBytes(bb);
		// System.out.println(Elementb);
		Element getb = getb();
		System.out.println(getb);

		// String g = "g";
		// byte[] gb = ReadAndWriteUtilis.readElement(g);
		// Element Elementg = G1.newElementFromBytes(gb);
		// System.out.println(Elementg);
		Element getg = getg();
		System.out.println(getg);
	}


	
	public static void writrgatoFile(int q) {
		Element gElement = getg();
		Element aElement = geta();
		LinkedHashMap<String, Element> getga = getga(q, gElement, aElement);
		Set<Entry<String, Element>> entrySet = getga.entrySet();
		for (Entry<String, Element> entry : entrySet) {
			String key = entry.getKey();
			Element value = entry.getValue();
			byte[] bytes = value.toBytes();
			try {
				ReadAndWriteUtilis.writeElement(bytes, key);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static void writrgbtoFile(int q) {
		Element gElement = getg();
		Element bElement = getb();
		LinkedHashMap<String, Element> getgb = getgb(q, gElement, bElement);
		Set<Entry<String, Element>> entrySet = getgb.entrySet();
		for (Entry<String, Element> entry : entrySet) {
			String key = entry.getKey();
			Element value = entry.getValue();
			byte[] bytes = value.toBytes();
			try {
				ReadAndWriteUtilis.writeElement(bytes, key);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}



	@Test
	public void test8() throws ClassNotFoundException, IOException {
		Element gElement = getg();
		Element bElement = getb();
		Element aElement = geta();
		LinkedHashMap<String, Element> getgab = getgab(20, gElement, aElement, bElement);
		Set<Entry<String, Element>> entrySet = getgab.entrySet();
		for (Entry<String, Element> entry : entrySet) {
			String key = entry.getKey();
			Element value = entry.getValue();
			byte[] bytes = value.toBytes();
			ReadAndWriteUtilis.writeElement(bytes, key);
		}
	}
	
	public static void writrgabtoFile(int q) {
		Element gElement = getg();
		Element bElement = getb();
		Element aElement = geta();
		LinkedHashMap<String, Element> getgab = getgab(q, gElement, aElement, bElement);
		Set<Entry<String, Element>> entrySet = getgab.entrySet();
		for (Entry<String, Element> entry : entrySet) {
			String key = entry.getKey();
			Element value = entry.getValue();
			byte[] bytes = value.toBytes();
			try {
				ReadAndWriteUtilis.writeElement(bytes, key);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

//	@Test
//	public void test9() throws ClassNotFoundException, IOException {
//		LinkedHashMap<String,Element> getgabFromFile = getgabFromFile(20);
//		Set<Entry<String, Element>> entrySet = getgabFromFile.entrySet();
//		for (Entry<String, Element> entry : entrySet) {
//			System.out.println(entry.getKey());
//			System.out.println(entry.getValue());
//		}
//	}

}
