package com.wzy.wr;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ReadAndWriteUtilis {
	public static void writeElement(byte[] b, String nameofelement) throws IOException {
		// 1.创建目标路径
		File file = new File("D:\\PVBFM\\PP\\PK\\PP\\" + nameofelement + ".txt");
		// 2.创建流通道
		FileOutputStream fos = new FileOutputStream(file);
		// 3.创建对象输出流
		ObjectOutputStream objOP = new ObjectOutputStream(fos);
		// 4.创建类对象，并初始化
		// SecretKey sk = generateKey();
		// 5.向目标路径文件写入对象
		objOP.writeObject(b);
		// 6.关闭资源
		objOP.close();
	}

	// 再读取对象
	public static byte[] readElement(String nameofelement) throws IOException, ClassNotFoundException {
		File file = new File("D:\\PVBFM\\PP\\PK\\PP\\" + nameofelement + ".txt");
		FileInputStream fis = new FileInputStream(file);
		ObjectInputStream objIP = new ObjectInputStream(fis);
		// 读取对象数据，需要将对象流强制转换为 要写入对象的类型
		byte[] sk = (byte[]) objIP.readObject();
		//System.out.println(sk);
		objIP.close();
		return sk;
	}
	
	public static void writeCom(byte[] b, String nameofelement) throws IOException {
		// 1.创建目标路径
		File file = new File("D:\\PVBFM\\PP\\PK\\Com\\" + nameofelement + ".txt");
		// 2.创建流通道
		FileOutputStream fos = new FileOutputStream(file);
		// 3.创建对象输出流
		ObjectOutputStream objOP = new ObjectOutputStream(fos);
		// 4.创建类对象，并初始化
		// SecretKey sk = generateKey();
		// 5.向目标路径文件写入对象
		objOP.writeObject(b);
		// 6.关闭资源
		objOP.close();
	}

	// 再读取对象
	public static byte[] readCom(String nameofelement) throws IOException, ClassNotFoundException {
		File file = new File("D:\\PVBFM\\PP\\PK\\Com\\" + nameofelement + ".txt");
		FileInputStream fis = new FileInputStream(file);
		ObjectInputStream objIP = new ObjectInputStream(fis);
		// 读取对象数据，需要将对象流强制转换为 要写入对象的类型
		byte[] sk = (byte[]) objIP.readObject();
		//System.out.println(sk);
		objIP.close();
		return sk;
	}
}
