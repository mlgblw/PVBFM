package com.wzy.wr;

import java.io.FileReader;
import java.io.IOException;

public class ReadFile {
	public static String Read(String readpath) {
		FileReader reader = null;
		String string = null;
		try {
			reader = new FileReader(readpath);
			char[] buffer = new char[1024];
			StringBuilder builder = new StringBuilder();
			int count;
			while ((count = reader.read(buffer)) != -1) {
				builder.append(buffer, 0, count);
			}
			string = builder.toString();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return string;
	}
}
