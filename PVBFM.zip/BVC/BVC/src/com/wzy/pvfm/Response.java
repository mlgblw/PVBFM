package com.wzy.pvfm;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import it.unisa.dia.gas.jpbc.Element;

public class Response {
	public ArrayList<Long> tagA = new ArrayList<>();
	public ArrayList<Long> tagB = new ArrayList<>();
	public ArrayList<Integer> IA = new ArrayList<>();
	public ArrayList<Integer> IB = new ArrayList<>();
	public ArrayList<Long[]> DSA = new ArrayList<>();
	public ArrayList<Long[]> DSB = new ArrayList<>();
	public ArrayList<Long[]> OA = new ArrayList<>();
	public ArrayList<Long[]> OB = new ArrayList<>();
	// ArrayList<byte[]> MS;
	public ArrayList<Integer[]> IBA = new ArrayList<>();
	public ArrayList<Integer[]> IAB = new ArrayList<>();
	public LinkedHashMap<String, Element> proofMap = new LinkedHashMap<>();

}
