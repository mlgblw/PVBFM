package com.wzy.icf;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.wzy.hash.HashUtils;

public class ICFUtils {
	public static int MaxLoop = 60;

	public static int deletebyId(ICF icf, int id) {
		if (icf.count[id - 1] == 0) {
			return 0;
		}
		icf.clear(id);
		return 1;
	}


	public static int deleteA(ICF icf, long delete) {
		int fa = fa(delete, icf.m);
		if (icf.count[fa - 1] == 0) {
			return 0;
		}
		if (delete == icf.x[fa - 1] / icf.count[fa - 1]) {
			icf.clear(fa);
			return 1;
		}
		return 0;
	}

	public static int deleteB(ICF icf, long delete) {
		int fb = fb(delete, icf.m);
		if (icf.count[fb - 1] == 0) {
			return 0;
		}

		if (delete == icf.x[fb - 1] / icf.count[fb - 1]) {
			icf.clear(fb);
			return 1;
		}
		return 0;
	}

	public static int delete(ICF icf, long delete) {
		int fa = fa(delete, icf.m);
		int fb = fb(delete, icf.m);
		if (deleteA(icf, delete) != 0 || deleteB(icf, delete) != 0) {
			return 1;
		}
		return 0;
	}

	public static int findA(ICF icf, long find) {
		int fa = fa(find, icf.m);
		if (icf.count[fa - 1] == 0) {
			return 0;
		}
		if (find == icf.x[fa - 1] / icf.count[fa - 1]) {

			return fa;
		}

		return 0;
	}

	public static int findB(ICF icf, long find) {
		int fb = fb(find, icf.m);
		if (icf.count[fb - 1] == 0) {
			return 0;
		}

		if (find == icf.x[fb - 1] / icf.count[fb - 1]) {

			return fb;
		}
		return 0;
	}

	public static int find(ICF icf, long find) {
		int fa = fa(find, icf.m);
		int fb = fb(find, icf.m);
		if (findA(icf, find) != 0) {
			return fa;
		}
		if (findB(icf, find) != 0) {
			return fb;
		}
		return 0;
	}

	public static int insert(ICF a, ICF b, long filed) {
		ICF c = new ICF();
		ICF d = new ICF();
		copyicf(c, a);
		copyicf(d, b);
		int length = a.m;
		long temp[] = new long[3];
		int time = 0;

		int temp1 = fa(filed, length);
		if (a.count[temp1 - 1] == 0) {
			a.insert(filed, temp1);
			return 1;
		}
		if (a.contain(filed)) {
			a.insert(filed, a.getidofx(filed));
			return 1;
		}
		temp1 = fb(filed, length);
		if (b.count[temp1 - 1] == 0) {
			b.insert(filed, temp1);
			return 1;
		}
		if (b.contain(filed)) {
			b.insert(filed, b.getidofx(filed));
			return 1;
		}

		temp[0] = 1;
		temp[1] = filed;
		temp[2] = g(filed);
		long[] temp2 = new long[3];
		for (int j = 0; j < MaxLoop; j++) {
			temp2[0] = temp[0];
			temp2[1] = temp[1];
			temp2[2] = temp[2];
			temp[0] = insertc(a, temp2[0], fa(temp2[1] / temp2[0], length));
			temp[1] = insertx(a, temp2[1], fa(temp2[1] / temp2[0], length));
			temp[2] = insertg(a, temp2[2], fa(temp2[1] / temp2[0], length));
			time++;

			if (temp[0] == 0) {
				System.out.println(time + " " + filed + " " + temp[1]);
				break;
			}

			temp2[0] = temp[0];
			temp2[1] = temp[1];
			temp2[2] = temp[2];
			temp[0] = insertc(b, temp2[0], fb(temp2[1] / temp2[0], length));
			temp[1] = insertx(b, temp2[1], fb(temp2[1] / temp2[0], length));
			temp[2] = insertg(b, temp2[2], fb(temp2[1] / temp2[0], length));

			if (temp[0] == 0) {
				System.out.println(time + " " + filed + " " + temp[1]);
				break;
			}

		}
		if (temp[0] != 0)
			System.out.println(time + " " + filed + " " + temp[1] / temp[0]);
		if (time == MaxLoop) {
			copyicf(a, c);
			copyicf(b, d);
			return 0;
		}
		return 1;

	}

	public static long insertc(ICF ccf, long countofccf, int id) {
		long i = ccf.count[id - 1];
		ccf.count[id - 1] = countofccf;
		return i;
	}

	public static long insertx(ICF ccf, long xofccf, int id) {
		long i = ccf.x[id - 1];
		ccf.x[id - 1] = xofccf;
		return i;
	}

	public static long insertg(ICF ccf, long gofccf, int id) {
		long i = ccf.g[id - 1];
		ccf.g[id - 1] = gofccf;
		return i;
	}

	public static int fa(long x, int m) {

		int i = HashUtils.JSHash(String.valueOf(x)) % m;
		if (i < 0) {
			return -i + 1;
		}
		return i + 1;
		// return ((x + 15) * 63) % m;
		// return (x * 31) % m;
	}

	public static int fb(long x, int m) {

		int i = HashUtils.FNVHash(String.valueOf(x)) % m;
		if (i < 0) {
			return -i + 1;
		}
		return i + 1;
		// return (x * 3 * 31) % m;
	}

	public static long g(long x) {
		long n = 9999;
		return (x * 55 * 31) % (n * n * n);
	}

	public static void copyicf(ICF copy, ICF becopied) {
		for (int i = 0; i < copy.x.length; i++) {
			copy.count[i] = becopied.count[i];
			copy.x[i] = becopied.x[i];
			copy.g[i] = becopied.g[i];
		}
	}

	public static void writeICF(ICF icf, String nameofelement) {
		// 1.创建目标路径
		File file = new File("D:\\PVBFM\\ICF\\" + nameofelement + ".txt");
		// 2.创建流通道
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 3.创建对象输出流
		ObjectOutputStream objOP = null;
		try {
			objOP = new ObjectOutputStream(fos);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 4.创建类对象，并初始化
		// SecretKey sk = generateKey();
		// 5.向目标路径文件写入对象
		try {
			objOP.writeObject(icf);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 6.关闭资源
		try {
			objOP.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 再读取对象
	public static ICF readICF(String nameofelement) {
		File file = new File("D:\\PVBFM\\ICF\\" + nameofelement + ".txt");
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ObjectInputStream objIP = null;
		try {
			objIP = new ObjectInputStream(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// 读取对象数据，需要将对象流强制转换为 要写入对象的类型
		ICF sk = null;
		try {
			sk = (ICF) objIP.readObject();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// System.out.println(sk);
		try {
			objIP.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sk;
	}

	public static void changBToA(ICF oldA, ICF nowA, ICF oldB, ArrayList<Integer[]> IBA, ArrayList<Long> tagA,
			ArrayList<Long[]> DSA, ArrayList<Integer> IA, ArrayList<Long[]> OA) {
		for (int i = 0; i < oldA.count.length; i++) {
			if (nowA.count[i] != 0 && oldA.count[i] == 0) {
				int getidofx = oldB.getidofx(nowA.x[i] / nowA.count[i]);
				if (getidofx == 0) {
					Long[] temp1 = new Long[] { (long) 0, (long) 0, (long) 0 };
					IA.add(nowA.getidofx(nowA.x[i] / nowA.count[i]));
					tagA.add(nowA.x[i] / nowA.count[i]);
					OA.add(temp1);
				}
				if (getidofx != 0) {
					Integer[] temp = new Integer[2];
					temp[0] = oldB.getidofx(nowA.x[i] / nowA.count[i]);
					temp[1] = nowA.getidofx(nowA.x[i] / nowA.count[i]);
					Long[] temp1 = new Long[3];
					temp1[0] = oldB.count[getidofx - 1];
					temp1[1] = oldB.x[getidofx - 1];
					temp1[2] = oldB.g[getidofx - 1];
					IBA.add(temp);
					tagA.add(nowA.x[i] / nowA.count[i]);
					DSA.add(temp1);
				}
			}

		}
		for (int i = 0; i < oldA.count.length; i++) {
			if (nowA.count[i] != 0 && oldA.count[i] != 0) {
				if (nowA.x[i] / nowA.count[i] != oldA.x[i] / oldA.count[i]) {
					int getidofx = oldB.getidofx(nowA.x[i] / nowA.count[i]);
					if (getidofx == 0) {
						Long[] temp1 = new Long[] { (long) 0, (long) 0, (long) 0 };
						IA.add(nowA.getidofx(nowA.x[i] / nowA.count[i]));
						tagA.add(nowA.x[i] / nowA.count[i]);
						OA.add(temp1);
					}
					if (getidofx != 0) {
						Integer[] temp = new Integer[2];
						temp[0] = oldB.getidofx(nowA.x[i] / nowA.count[i]);
						temp[1] = nowA.getidofx(nowA.x[i] / nowA.count[i]);
						Long[] temp1 = new Long[3];
						temp1[0] = oldB.count[getidofx];
						temp1[1] = oldB.x[getidofx];
						temp1[2] = oldB.g[getidofx];
						IBA.add(temp);
						tagA.add(nowA.x[i] / nowA.count[i]);
						DSA.add(temp1);
					}
				}
			}

		}
		for (int i = 0; i < oldA.count.length; i++) {
			if (oldA.count[i] != 0) {
				if ((nowA.x[i] / nowA.count[i] == oldA.x[i] / oldA.count[i]) && (nowA.count[i] != oldA.count[i])) {
					int getidofx = nowA.getidofx(nowA.x[i] / nowA.count[i]);
					IA.add(nowA.getidofx(nowA.x[i] / nowA.count[i]));
					Long[] temp1 = new Long[3];
					temp1[0] = oldA.count[getidofx - 1];
					temp1[1] = oldA.x[getidofx - 1];
					temp1[2] = oldA.g[getidofx - 1];
					tagA.add(oldA.x[i] / oldA.count[i]);
				}
			}
		}
	}

	public static void changAToB(ICF oldB, ICF nowB, ICF oldA, ArrayList<Integer[]> IAB, ArrayList<Long> tagB,
			ArrayList<Long[]> DSB, ArrayList<Integer> IB, ArrayList<Long[]> OB) {
		for (int i = 0; i < oldB.count.length; i++) {
			if (nowB.count[i] != 0 && oldB.count[i] == 0) {
				int getidofx = oldA.getidofx(nowB.x[i] / nowB.count[i]);
				if (getidofx == 0) {
					Long[] temp1 = new Long[] { (long) 0, (long) 0, (long) 0 };
					IB.add(nowB.getidofx(nowB.x[i] / nowB.count[i]));
					tagB.add(nowB.x[i] / nowB.count[i]);
					OB.add(temp1);
				}
				if (getidofx != 0) {
					Integer[] temp = new Integer[2];
					temp[0] = oldA.getidofx(nowB.x[i] / nowB.count[i]);
					temp[1] = nowB.getidofx(nowB.x[i] / nowB.count[i]);
					Long[] temp1 = new Long[3];
					temp1[0] = oldA.count[getidofx - 1];
					temp1[1] = oldA.x[getidofx - 1];
					temp1[2] = oldA.g[getidofx - 1];
					IAB.add(temp);
					tagB.add(nowB.x[i] / nowB.count[i]);
					DSB.add(temp1);
				}
			}

		}
		for (int i = 0; i < oldB.count.length; i++) {
			if (nowB.count[i] != 0 && oldB.count[i] != 0) {
				if (nowB.x[i] / nowB.count[i] != oldB.x[i] / oldB.count[i]) {
					int getidofx = oldA.getidofx(nowB.x[i] / nowB.count[i]);
					if (getidofx == 0) {
						Long[] temp1 = new Long[] { (long) 0, (long) 0, (long) 0 };
						IB.add(nowB.getidofx(nowB.x[i] / nowB.count[i]));
						tagB.add(nowB.x[i] / nowB.count[i]);
						OB.add(temp1);
					}
					if (getidofx != 0) {
						Integer[] temp = new Integer[2];
						temp[0] = oldA.getidofx(nowB.x[i] / nowB.count[i]);
						temp[1] = nowB.getidofx(nowB.x[i] / nowB.count[i]);
						Long[] temp1 = new Long[3];
						temp1[0] = oldA.count[getidofx - 1];
						temp1[1] = oldA.x[getidofx - 1];
						temp1[2] = oldA.g[getidofx - 1];
						IAB.add(temp);
						tagB.add(nowB.x[i] / nowB.count[i]);
						DSB.add(temp1);
					}
				}
			}

		}
		for (int i = 0; i < oldB.count.length; i++) {
			if (oldB.count[i] != 0) {
				if ((nowB.x[i] / nowB.count[i] == oldB.x[i] / oldB.count[i]) && (nowB.count[i] != oldB.count[i])) {
					int getidofx = nowB.getidofx(nowB.x[i] / nowB.count[i]);
					IB.add(nowB.getidofx(nowB.x[i] / nowB.count[i]));
					Long[] temp1 = new Long[3];
					temp1[0] = oldB.count[getidofx - 1];
					temp1[1] = oldB.x[getidofx - 1];
					temp1[2] = oldB.g[getidofx - 1];
					tagB.add(nowB.x[i] / nowB.count[i]);
				}
			}
		}
	}

	public static void findInA(ICF icfA, ArrayList<Long> tag, ArrayList<Long> tagA, ArrayList<Integer> IA,
			ArrayList<Long[]> DSA, ArrayList<Long> countA) {
		for (long integertag : tag) {
			int findA = findA(icfA, integertag);
			if (findA != 0) {
				tagA.add(icfA.x[findA - 1] / icfA.count[findA - 1]);
				Long[] temp = new Long[3];
				temp[0] = icfA.count[findA - 1];
				temp[1] = icfA.x[findA - 1];
				temp[2] = icfA.g[findA - 1];
				countA.add(temp[0]);
				IA.add(findA);
				DSA.add(temp);
				icfA.clear(findA);
			}
		}
	}

	public static void findInB(ICF icfB, ArrayList<Long> tag, ArrayList<Long> tagB, ArrayList<Integer> IB,
			ArrayList<Long[]> DSB, ArrayList<Long> countB) {
		for (long integertag : tag) {
			int findB = findB(icfB, integertag);
			if (findB != 0) {
				tagB.add(icfB.x[findB - 1] / icfB.count[findB - 1]);
				Long[] temp = new Long[3];
				temp[0] = icfB.count[findB - 1];
				temp[1] = icfB.x[findB - 1];
				temp[2] = icfB.g[findB - 1];
				countB.add(temp[0]);
				IB.add(findB);
				DSB.add(temp);
				icfB.clear(findB);
			}
		}
	}
}
