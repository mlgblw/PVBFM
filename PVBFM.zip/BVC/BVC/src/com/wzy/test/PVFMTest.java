package com.wzy.test;

import java.util.ArrayList;

import org.junit.Test;

import com.wzy.enc.FileUtils;
import com.wzy.icf.ICF;
import com.wzy.icf.ICFUtils;
import com.wzy.pvfm.PVFM;
import com.wzy.pvfm.Response;
import com.wzy.pvfm.ResponseDel;

public class PVFMTest {
	@Test
	public void testinit() {
		long currentTimeMillis = System.currentTimeMillis();
		PVFM.setup(200);
		long currentTimeMillis2 = System.currentTimeMillis();
		System.out.println((currentTimeMillis2-currentTimeMillis)/1000);
	}

	@Test
	public void testrequest() {
		String path = "D:\\PVBFM\\FileList";
		ArrayList<Long> requestgen = PVFM.requestgen(path);
		System.out.println(requestgen.toString());
	}

	@Test
	public void testresponseUpload() {
		String path = "D:\\PVBFM\\FileList";
		ArrayList<String> fArrayList = new ArrayList<>();
		ArrayList<Long> requestgen = PVFM.requestgen(path);
		ArrayList<String> fileList = FileUtils.getFileList(path);
		Response response = PVFM.responseUpload(fileList, fArrayList, requestgen, 50);

	}

	@Test
	public void test2() {
		ICF icfA = ICFUtils.readICF("icfA");
		ICF icfB = ICFUtils.readICF("icfB");
		System.out.println("icfA");
		icfA.show();
		System.out.println("icfB");
		icfB.show();
	}

	@Test
	public void testbatchupload() {
		String path = "D:\\PVBFM\\FileList";
		ArrayList<String> fArrayList = new ArrayList<>();
		ArrayList<Long> requestgen = PVFM.requestgen(path);
		ArrayList<String> fileList = FileUtils.getFileList(path);
		Response response = PVFM.responseUpload(fileList, fArrayList, requestgen, 50);
		PVFM.batchupload(response, 50, fileList, fArrayList);
	}

	@Test
	public void testbatchDown() {
		String path = "D:\\PVBFM\\FileList";
		ArrayList<Long> requestgen = PVFM.requestgen(path);
		ArrayList<String> filelist = FileUtils.getFileList(path);
		ResponseDel responseDownLoad = PVFM.responseDownLoad(filelist, requestgen, 50);
		PVFM.batchDownload(responseDownLoad, filelist, 50);
	}
	
	
	@Test
	public void testbatchDel() {
		String path = "D:\\PVBFM\\DelFileList";
		ArrayList<Long> requestgen = PVFM.requestgen(path);
		ArrayList<String> filelist = FileUtils.getFileList(path);
		ResponseDel responseDel = PVFM.responseDel(filelist, requestgen, 50);
		PVFM.batchdel(responseDel, filelist, 50);
	}
}
