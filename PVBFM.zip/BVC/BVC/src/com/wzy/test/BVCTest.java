package com.wzy.test;

import java.io.IOException;
import java.util.Random;

import org.junit.Test;

import com.wzy.bvc.BVC;
import com.wzy.wr.ReadAndWriteUtilis;

import it.unisa.dia.gas.jpbc.Element;

public class BVCTest {
	@Test
	public void testCom() {
		int q = 50;
		long[] M = new long[q];
		for (int i = 0; i < q; i++) {
			M[i] = 0;
		}
		// for (int i : M) {
		// System.out.println(i);
		// }
		Element com = BVC.Com(M, q);
//		byte[] bytes = com.toBytes();
//		try {
//			ReadAndWriteUtilis.writeCom(bytes, "ComA");
//			ReadAndWriteUtilis.writeCom(bytes, "ComB");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		System.out.println(com);
	}

	@Test
	public void testBatchOpen() {
		int q = 50;
		long[] M = new long[q];
		for (int i = 0; i < q; i++) {
			Random random = new Random();
			M[i] = random.nextInt(101);
		}
		Element com = BVC.Com(M, q);
		// System.out.println(com);
		int[] I = new int[] { 1, 7, 50 };
		Element batchOpen = BVC.BatchOpen(M, I, 50);
		System.out.println(batchOpen);

	}

	@Test
	public void testBatvhVer() {
		int q = 50;
		long[] M = new long[q];
		for (int i = 0; i < q; i++) {
			M[i] = 0;
		}
		Element com = BVC.Com(M, q);
		// System.out.println(com);
		int[] I = new int[] { 1, 8, 50 };
		Element batchOpen = BVC.BatchOpen(M, I, 50);
		System.out.println(batchOpen);
		int batchVer = BVC.BatchVer(com, M, I, batchOpen, q);
		System.out.println(batchVer);
	}

	@Test
	public void testBatchUpd() {
		int q = 50;
		long[] M = new long[q];
		for (int i = 0; i < q; i++) {
			M[i] = 0;
		}
		Element com = BVC.Com(M, q);
		System.out.println(com);
		int[] I = new int[] { 1, 7, 50 };
		Element batchOpen = BVC.BatchOpen(M, I, 50);
		System.out.println(batchOpen);
		int batchVer = BVC.BatchVer(com, M, I, batchOpen, q);
		System.out.println(batchVer);
		long[] SU = new long[] { 20, 43, 23 };
		Element batchUpd = BVC.BatchUpd(com, I, SU, 50);
		System.out.println(batchUpd);
	}
}
